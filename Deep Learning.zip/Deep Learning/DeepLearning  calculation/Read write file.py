import torch
from torch import nn
from torch.nn import functional as F

'''加载和保存张量'''
x = torch.arange(4)
torch.save(x, 'x-file')

x2 = torch.load('x-file')
print(x2)       #tensor([0, 1, 2, 3])

'''存储一个张量列表，然后把它读取到内存'''
y = torch.zeros(4)
torch.save([x, y],'x-files')
x2, y2 = torch.load('x-files')
print(x2, y2)       #tensor([0, 1, 2, 3]) tensor([0., 0., 0., 0.])

'''写入或读取从字符串映射到张量的字典'''
mydict = {'x': x, 'y': y}
torch.save(mydict, 'mydict')
mydict2 = torch.load('mydict')
print(mydict2)      #{'x': tensor([0, 1, 2, 3]), 'y': tensor([0., 0., 0., 0.])}


'''加载和保存模型参数'''
class MLP(nn.Module):
    def __init__(self):
        super().__init__()
        self.hidden = nn.Linear(20, 256)
        self.output = nn.Linear(256, 10)

    def forward(self, x):
        return self.output(F.relu(self.hidden(x)))

net = MLP()
X = torch.randn(size=(2, 20))
Y = net(X)

'''我们将模型的参数存储在一个叫做“mlp.params”的文件中。'''
torch.save(net.state_dict(), 'mlp.params')


'''为了恢复模型，我们实例化了原始多层感知机模型的一个备份。 这里我们不需要随机初始化模型参数，而是直接读取文件中存储的参数。'''
clone = MLP()
clone.load_state_dict(torch.load('mlp.params'))
print(clone.eval())
'''MLP(
  (hidden): Linear(in_features=20, out_features=256, bias=True)
  (output): Linear(in_features=256, out_features=10, bias=True)
)'''

'''由于两个实例具有相同的模型参数，在输入相同的X时， 两个实例的计算结果应该相同。 让我们来验证一下。'''
Y_clone = clone(X)
print(Y_clone == Y)
'''tensor([[True, True, True, True, True, True, True, True, True, True],
        [True, True, True, True, True, True, True, True, True, True]])'''
