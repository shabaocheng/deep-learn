'''首先关注具有单隐藏层的多层感知机'''

import torch
from torch import nn

'''构建一个具有单隐藏层的多层感知机。'''
net = nn.Sequential(nn.Linear(4, 8), nn.ReLU(), nn.Linear(8, 1))
x = torch.rand(size=(2, 4))
print(net(x))

'''我们从已有模型中访问参数。 当通过Sequential类定义模型时， 我们可以通过索引来访问模型的任意层。
这就像模型是一个列表一样，每层的参数都在其属性中。 如下所示，我们可以检查第二个全连接层的参数。'''
print(net[2].state_dict())  #net[2]是最后的输出层nn.Linear（8，1）
#OrderedDict([('weight', tensor([[ 0.3500,  0.1324,  0.0502,  0.2578,  0.2946,  0.1767, -0.1135, -0.0110]])),
# ('bias', tensor([-0.2984]))])

'''目标参数'''
print(type(net[2].bias))
#<class 'torch.nn.parameter.Parameter'>
print(net[2].bias)
#Parameter containing:
#tensor([-0.1713], requires_grad=True)
print(net[2].bias.data)         #.data访问数值
#tensor([-0.1713])
print(net[2].weight.grad == None)       #True   .grad访问梯度，还没做反向计算，所以为None
print('\n')

'''一次性访问所有参数named_parameters()'''
print(*[(name, param.shape) for name, param in net[0].named_parameters()])
#('weight', torch.Size([8, 4])) ('bias', torch.Size([8]))
print(*[(name, param.shape) for name, param in net.named_parameters()])
#('0.weight', torch.Size([8, 4])) ('0.bias', torch.Size([8])) ('2.weight', torch.Size([1, 8])) ('2.bias', torch.Size([1]))
print(net.state_dict()['2.bias'].data)          #tensor([0.0446])
print('\n')
'''从嵌套块中收集参数'''
'''如果我们将多个块相互嵌套，参数命名约定是如何工作的。 我们首先定义一个生成块的函数（可以说是“块工厂”），然后将这些块组合到更大的块中。'''
def block1():
    return nn.Sequential(nn.Linear(4, 8), nn.ReLU(),
                         nn.Linear(8, 4), nn.ReLU())

def block2():
    net = nn.Sequential()
    for i in range(4):
        # 在这里嵌套
        net.add_module(f'block {i}', block1())
    return net

rgnet = nn.Sequential(block2(), nn.Linear(4, 1))
#print(rgnet)
rgnet(x)

'''因为层是分层嵌套的，所以我们也可以像通过嵌套列表索引一样访问它们。 下面，我们访问第一个主要的块中、第二个子块的第一层的偏置项。'''
print(rgnet[0][1][0].bias.data)

'''参数初始化'''
'''默认情况下，PyTorch会根据一个范围均匀地初始化权重和偏置矩阵， 这个范围是根据输入和输出维度计算出的。 
PyTorch的nn.init模块提供了多种预置初始化方法。'''

'''内置初始化
让我们首先调用内置的初始化器。 下面的代码将所有权重参数初始化为标准差为0.01的高斯随机变量， 且将偏置参数设置为0。'''
def init_normal(m):
    if type(m) == nn.Linear:
        nn.init.normal_(m.weight, mean=0, std=0.01)         #normal_,下划线的意思是替换函数，将m.weight替换掉
        nn.init.zeros_(m.bias)          #bias赋值为0

net.apply(init_normal)          #apply()函数，对于net里面所有的layer，for loop把init_normal传入进去（递归遍历）
print(net[0].weight.data[0], net[0].bias.data[0])
#tensor([-0.0247, -0.0122, -0.0123,  0.0011]) tensor(0.)


def init_constant(m):
    if type(m) == nn.Linear:
        nn.init.constant_(m.weight, 1)
        nn.init.zeros_(m.bias)
net.apply(init_constant)
print(net[0].weight.data[0], net[0].bias.data[0])
#tensor([1., 1., 1., 1.]) tensor(0.)
print('\n')

'''对某些块应用不同的初始化方法'''
def xavier(m):
    if type(m) == nn.Linear:
        nn.init.xavier_uniform_(m.weight)       #xavier 均值
def init_42(m):
    if type(m) == nn.Linear:
        nn.init.constant_(m.weight, 42)

net[0].apply(xavier)
net[2].apply(init_42)
print(net[0].weight.data[0])        #tensor([-0.4839,  0.4340, -0.6467,  0.1811])
print(net[2].weight.data)           #tensor([[42., 42., 42., 42., 42., 42., 42., 42.]])


'''自定义初始化'''
'''实现了一个my_init函数来应用到net。'''
def my_init(m):
    if type(m) == nn.Linear:
        print("Init", *[(name, param.shape)
                        for name, param in m.named_parameters()][0])
        nn.init.uniform_(m.weight, -10, 10)
        m.weight.data *= m.weight.data.abs() >= 5

net.apply(my_init)
print(net[0].weight[:2])
'''
Init weight torch.Size([8, 4])
Init weight torch.Size([1, 8])
tensor([[-0.0000,  0.0000, -0.0000, -7.9754],
        [-7.8066,  5.1921, -5.9793, -7.8184]], grad_fn=<SliceBackward>)'''

'''注意，我们始终可以直接设置参数。'''
net[0].weight.data[:] += 1
net[0].weight.data[0, 0] = 42
print(net[0].weight.data[0])        #tensor([42.0000,  1.0000, -7.3090, -5.7755])

'''参数绑定
有时我们希望在多个层间共享参数： 我们可以定义一个稠密层，然后使用它的参数来设置另一个层的参数。'''
# 我们需要给共享层一个名称，以便可以引用它的参数
shared = nn.Linear(8, 8)
net = nn.Sequential(nn.Linear(4, 8), nn.ReLU(),
                    shared, nn.ReLU(),
                    shared, nn.ReLU(),
                    nn.Linear(8, 1))
net(x)
# 检查参数是否相同
print(net[2].weight.data[0] == net[4].weight.data[0])
#tensor([True, True, True, True, True, True, True, True])

net[2].weight.data[0, 0] = 100
# 确保它们实际上是同一个对象，而不只是有相同的值
print(net[2].weight.data[0] == net[4].weight.data[0])
#tensor([True, True, True, True, True, True, True, True])



























