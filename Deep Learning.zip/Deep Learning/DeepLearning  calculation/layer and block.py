import torch
from torch import nn
from torch.nn import functional as F

'''回顾下多层感知机'''
#线性层+relu+线性层
net = nn.Sequential(nn.Linear(20, 256), nn.ReLU(), nn.Linear(256, 10))
# 2为批量大小，20为批量的维度
x = torch.rand(2, 20)
#print(net(x))

'''自定义块'''
class MLP(nn.Module):       #MLP是nn.Module的子类
    # 用模型参数声明层。这里，我们声明两个全连接的层
    def __init__(self):
        # 调用MLP的父类Module的构造函数来执行必要的初始化。
        # 这样，在类实例化时也可以指定其他函数参数，例如模型参数params（稍后将介绍）
        super().__init__()
        self.hidden = nn.Linear(20, 256)  # 隐藏层，输入维度20，输出维度256
        self.out = nn.Linear(256, 10)  # 输出层，输入维度256，输出维度10

    # 定义模型的前向传播，即如何根据输入X返回所需的模型输出
    def forward(self, X):
        # 注意，这里我们使用ReLU的函数版本，其在nn.functional模块中定义。
        return self.out(F.relu(self.hidden(X))) #先将输入放进hidden做输出，然后放进ReLu激活函数中，然后再放进out输出返回。

#net = MLP()
#print(net(x))      #输出（2，10）的矩阵

'''顺序块'''
class MySequential(nn.Module):
    def __init__(self, *args):
        super().__init__()
        for block in args:
            self._modules[block] = block

    def forward(self, x):
        # OrderedDict保证了按照成员添加的顺序遍历它们
        for block in self._modules.values():
            x = block(x)
        return x

'''当MySequential的前向传播函数被调用时， 每个添加的块都按照它们被添加的顺序执行。
现在可以使用我们的MySequential类重新实现多层感知机。'''
#net = MySequential(nn.Linear(20, 256), nn.ReLU(), nn.Linear(256, 10))
#print(net(x))              #输出（2，10）的矩阵


'''在前向传播函数中执行代码'''
class FixedHiddenMLP(nn.Module):
    def __init__(self):
        super().__init__()
        # 不计算梯度的随机权重参数。因此其在训练期间保持不变
        self.rand_weight = torch.rand((20, 20), requires_grad=False)
        self.linear = nn.Linear(20, 20)

    def forward(self, x):
        x = self.linear(x)
        # 使用创建的常量参数以及relu和mm函数
        x = F.relu(torch.mm(x, self.rand_weight) + 1)
        # 复用全连接层。这相当于两个全连接层共享参数
        x = self.linear(x)
        # 控制流
        while x.abs().sum() > 1:
            x /= 2
        return x.sum()

net = FixedHiddenMLP()
print(net(x))


'''我们可以混合搭配各种组合块的方法'''
class NestMLP(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(20, 64), nn.ReLU(),
                                 nn.Linear(64, 32), nn.ReLU())
        self.linear = nn.Linear(32, 16)

    def forward(self, x):
        return self.linear(self.net(x))

chimera = nn.Sequential(NestMLP(), nn.Linear(16, 20), FixedHiddenMLP())
print(chimera(x))





















