import torch
from torch import nn
import torch.nn.functional as F

'''构造一个没有参数的自定义层'''

class CenteredLayer(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, X):
        return X - X.mean()

layer = CenteredLayer()
print(layer(torch.FloatTensor([1, 2, 3, 4, 5])))
#tensor([-2., -1.,  0.,  1.,  2.]) 均值为0

'''可以将层作为组件合并到更复杂的模型中。'''
net = nn.Sequential(nn.Linear(8, 128), CenteredLayer())
'''作为额外的健全性检查，我们可以在向该网络发送随机数据后，检查均值是否为0。
由于我们处理的是浮点数，因为存储精度的原因，我们仍然可能会看到一个非常小的非零数。'''
Y = net(torch.rand(4, 8))
print(Y.mean())         #tensor(5.5879e-09, grad_fn=<MeanBackward0>)

'''实现自定义版本的全连接层。 回想一下，该层需要两个参数，一个用于表示权重，另一个用于表示偏置项。
在此实现中，我们使用修正线性单元作为激活函数。'''
'''该层需要输入参数：in_units和units，分别表示输入数和输出数'''
class MyLinear(nn.Module):
    def __init__(self, in_units, units):
        super().__init__()
        self.weight = nn.Parameter(torch.randn(in_units, units))        #nn.Parameter把梯度加上
        self.bias = nn.Parameter(torch.randn(units,))
    def forward(self, x):
        linear = torch.matmul(x, self.weight.data) + self.bias.data
        return F.relu(linear)


'''实例化MyLinear类并访问其模型参数。'''
linear = MyLinear(5, 3)
print(linear.weight)
'''Parameter containing:
tensor([[-0.3279,  1.5675,  0.2036],
        [ 0.9673, -1.2979, -1.6255],
        [ 0.1033,  1.0203,  0.9496],
        [-0.6095, -0.0602, -0.8870],
        [ 1.2722,  1.3629, -0.1594]], requires_grad=True)'''

'''使用自定义层直接执行前向传播计算。'''
print(linear(torch.rand(2, 5)))
'''tensor([[0.0000, 0.0000, 1.0713],
        [0.0000, 0.8598, 0.8935]])'''

'''还可以使用自定义层构建模型，就像使用内置的全连接层一样使用自定义层。'''
net = nn.Sequential(MyLinear(64, 8), MyLinear(8, 1))
print(net(torch.rand(2, 64)))
'''tensor([[0.],
        [0.]])'''
