import torch
from  torch import nn


'''计算设备'''
print(torch.device('cpu'), torch.cuda.device('cuda'), torch.cuda.device('cuda:1'))
#访问第0个和第1个GPU

'''查看可用gpu的数量'''
print(torch.cuda.device_count())
print(torch.cuda.is_available())

'''现在我们定义了两个方便的函数， 这两个函数允许我们在不存在所需所有GPU的情况下运行代码。'''
def try_gpu(i=0):  #@save
    """如果存在，则返回gpu(i)，否则返回cpu()"""
    if torch.cuda.device_count() >= i + 1:
        return torch.device(f'cuda:{i}')
    return torch.device('cpu')

def try_all_gpus():  #@save
    """返回所有可用的GPU，如果没有GPU，则返回[cpu(),]"""
    devices = [torch.device(f'cuda:{i}')
             for i in range(torch.cuda.device_count())]
    return devices if devices else [torch.device('cpu')]

print(try_gpu(), try_gpu(10), try_all_gpus())

'''查询张量所在设备'''
x = torch.tensor([1, 2, 3])
print(x.device)

'''存储在GPU上'''
X = torch.ones(2, 3, device=try_gpu())
print(X)
'''假设你至少有两个GPU，下面的代码将在第二个GPU上创建一个随机张量。'''
Y = torch.rand(2, 3, device=try_gpu(1))
print(Y)

'''复制
如果我们要计算X + Y，我们需要决定在哪里执行这个操作。'''
Z = X.cuda()
print(X)
print(Z)






























