import torch
from torch import nn
from d2l import torch as d2l

'''填充'''

# 定义了一个计算卷积层的函数。
# 此函数初始化卷积层权重，并对输入和输出提高和缩减相应的维数
def comp_conv2d(conv2d, X):
    # 这里的（1，1）表示批量大小和通道数都是1
    X = X.reshape((1, 1) + X.shape)
    Y = conv2d(X)
    # 省略前两个维度：批量大小和通道
    return Y.reshape(Y.shape[2:])

# 请注意，这里每边都填充了1行或1列，因此总共添加了2行或2列
conv2d = nn.Conv2d(1, 1, kernel_size=3, padding=1)
Z = torch.rand(size=(8, 8))
print(comp_conv2d(conv2d, Z).shape)     #torch.Size([8, 8]) 8-3+2+1=8

'''填充不同的高度和宽度'''
conv2d = nn.Conv2d(1, 1, kernel_size=(5, 3), padding=(2, 1))    #上下填充2行，左右填充1列
print(comp_conv2d(conv2d, Z).shape)     #torch.Size([8, 8])


'''步幅'''
'''将高度和宽度的步幅设置为2，从而将输入的高度和宽度减半。'''
conv2d = nn.Conv2d(1, 1, kernel_size=3, padding=1, stride=2)
print(comp_conv2d(conv2d, Z).shape)     #torch.Size([4, 4])


'''复杂例子'''
conv2d = nn.Conv2d(1, 1, kernel_size=(3, 5), padding=(0, 1), stride=(3, 4))
print(comp_conv2d(conv2d, Z).shape)     #torch.Size([2, 2])