import torch
from torch import nn
from d2l import torch as d2l

'''互相关运算'''
def corr2d(X, K):  #x为输入，k为卷积核矩阵
    """计算二维互相关运算"""
    h, w = K.shape      #h，w为行数和列数
    # Y的高为输入的高减去核的高+1，Y的宽为输入的宽减去核的宽+1，
    Y = torch.zeros((X.shape[0] - h + 1, X.shape[1] - w + 1))
    #遍历，从x的i行开始往后看h行，从x的i列开始往后看w列
    for i in range(Y.shape[0]):
        for j in range(Y.shape[1]):
            Y[i, j] = (X[i:i + h, j:j + w] * K).sum()   #对应相乘再相加
    return Y


X = torch.tensor([[0.0, 1.0, 2.0], [3.0, 4.0, 5.0], [6.0, 7.0, 8.0]])
print(X)
K = torch.tensor([[0.0, 1.0], [2.0, 3.0]])
print(K)
print(corr2d(X, K))


'''实现2维卷积层
在__init__构造函数中，将weight和bias声明为两个模型参数。前向传播函数调用corr2d函数并添加偏置。'''
class Conv2D(nn.Module):
    def __init__(self, kernel_size):    #kernel_size超参数，自己指定
        super().__init__()
        self.weight = nn.Parameter(torch.rand(kernel_size))    #type是Parameter
        self.bias = nn.Parameter(torch.zeros(1))    #初始化为1个0
#前向运算
    def forward(self, x):
        return corr2d(x, self.weight) + self.bias

'''图像中目标的边缘检测
如下是卷积层的一个简单应用：通过找到像素变化的位置，来检测图像中不同颜色的边缘.
首先，我们构造一个像素的黑白图像。中间四列为黑色（0），其余像素为白色（1）。'''
X = torch.ones((6, 8))
X[:, 2:6] = 0
print(X)

'''构造一个高度为、宽度为的卷积核K。当进行互相关运算时，如果水平相邻的两元素相同，则输出为零，否则输出为非零。'''
K = torch.tensor([[1.0, -1.0]])
'''我们对参数X（输入）和K（卷积核）执行互相关运算。
输出Y中的1代表从白色到黑色的边缘，-1代表从黑色到白色的边缘，其他情况的输出为。'''
Y = corr2d(X, K)
print(Y)

'''将输入的二维图像转置，再进行如上的互相关运算。 
之前检测到的垂直边缘消失了。这个卷积核K只可以检测垂直边缘，无法检测水平边缘。'''
print(corr2d(X.t(), K))

'''学习卷积核'''
# 构造一个二维卷积层，它具有1个输出通道和形状为（1，2）的卷积核
conv2d = nn.Conv2d(1,1, kernel_size=(1, 2), bias=False)

# 这个二维卷积层使用四维输入和输出格式（批量大小、通道、高度、宽度），
# 其中批量大小和通道数都为1
X = X.reshape((1, 1, 6, 8))
Y = Y.reshape((1, 1, 6, 7))
lr = 3e-2  # 学习率

for i in range(10):
    Y_hat = conv2d(X)
    l = (Y_hat - Y) ** 2    #均方误差损失函数
    conv2d.zero_grad()      #梯度设成0
    l.sum().backward()      #梯度下降
    # 迭代卷积核
    conv2d.weight.data[:] -= lr * conv2d.weight.grad    #学习率*梯度
    if (i + 1) % 2 == 0:    #2个batch后进行epoch
        print(f'epoch {i+1}, loss {l.sum():.3f}')

'''所学的卷积核的权重张量'''
print(conv2d.weight.data.reshape((1, 2)))
print('\n')



'''填充'''

# 定义了一个计算卷积层的函数。
# 此函数初始化卷积层权重，并对输入和输出提高和缩减相应的维数
def comp_conv2d(conv2d, X):
    # 这里的（1，1）表示批量大小和通道数都是1
    X = X.reshape((1, 1) + X.shape)
    Y = conv2d(X)
    # 省略前两个维度：批量大小和通道
    return Y.reshape(Y.shape[2:])

# 请注意，这里每边都填充了1行或1列，因此总共添加了2行或2列
conv2d = nn.Conv2d(1, 1, kernel_size=3, padding=1)
Z = torch.rand(size=(8, 8))
print(comp_conv2d(conv2d, Z).shape)     #torch.Size([8, 8]) 8-3+2+1=8

'''填充不同的高度和宽度'''
conv2d = nn.Conv2d(1, 1, kernel_size=(5, 3), padding=(2, 1))    #上下填充2行，左右填充1列
print(comp_conv2d(conv2d, Z).shape)     #torch.Size([8, 8])


'''步幅'''
'''将高度和宽度的步幅设置为2，从而将输入的高度和宽度减半。'''
conv2d = nn.Conv2d(1, 1, kernel_size=3, padding=1, stride=2)
print(comp_conv2d(conv2d, Z).shape)     #torch.Size([4, 4])


'''复杂例子'''
conv2d = nn.Conv2d(1, 1, kernel_size=(3, 5), padding=(0, 1), stride=(3, 4))
print(comp_conv2d(conv2d, Z).shape)     #torch.Size([2, 2])
