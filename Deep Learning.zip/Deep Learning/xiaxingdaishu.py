import torch

#标量是只有一个元素的张量表示
x = torch.tensor([3.0])
y = torch.tensor([2.0])
print(x+y, x*y, x**y, x/y)

#可以将向量视为标量的列表
z = torch.arange(5)
print(z)
print(z[3])

#访问张量长度
print(len(z))
print(z.shape)
print('\n')
#创建矩阵
A = torch.arange(20).reshape(5,4)
print(A)
#矩阵的转置
print(A.T)
print('\n')
#向量是标量的推广，矩阵是向量的推广，我们可以构建更多轴的数据结构
B = torch.arange(24).reshape(2,3,4)
print(B)
print('\n')

#给定具有相同形状的任意两个张量，任何按元素二元运算的结果都将是相同形状的张量。 例如，将两个相同形状的矩阵相加，会在这两个矩阵上执行元素加法。
C = torch.arange(20, dtype=torch.float32).reshape(5, 4)
D = A.clone()  # 通过分配新内存，将A的一个副本分配给B
print(C,'\n',C+D)

#将张量乘以或加上一个标量不会改变张量的形状，其中张量的每个元素都将与标量相加或相乘。
#%%

a = 2
M = torch.arange(24).reshape(2, 3, 4)
print(a + M, (a * M).shape)






