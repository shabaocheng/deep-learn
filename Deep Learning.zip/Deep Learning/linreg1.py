#从零开始实现整个方法，包括数据流水线，模型，损失函数和小批量随机梯度下降优化器
import matplotlib.pyplot as plt
import torch
import random
import d2lzh_pytorch as d2l

'''根据带有噪声的线性模型构造一个人造数据集，我们使用线性模型参数w=[2，-3.4]T、b=4.2和噪声项€生成数据集以及标签
                            y = xw + b + €'''
def synthetic_data(w, b, num_examples):
    ''' 生成y=Xw+b+噪声 '''
    x = torch.normal(0, 1, (num_examples,len(w)))
    y = torch.matmul(x, w)+b
    y += torch.normal(0, 0.01, y.shape)
    return x, y.reshape((-1, 1))
true_w = torch.tensor([2,-3.4])
true_b = 4.2
features,labels = synthetic_data(true_w,true_b,1000)
'''features中的每一行都包含一个二维数据样本，labels中的每一行都包含一维标签值（一个标量）'''
print('features:',features[0],'\nlabels:', labels[0])

#d2l.set_figsize()
#d2l.plt.scatter(features[:,1].detach().numpy(),labels.detach().numpy(),1)
#plt.show()

'''定义一个data_ter函数，该函数接受批量大小、特征矩阵的标签向量作为输入，生成大小为batch_size的小批量'''
def data_iter(batch_size,features,labels):
    num_examples = len(features)
    indices = list(range(num_examples))
    #这些样本是随机读取的，没有特定的顺序
    random.shuffle(indices)
    for i in range(0, num_examples, batch_size):
        batch_indices = torch.tensor(indices[i:min(i+batch_size,num_examples)])
        yield features[batch_indices],labels[batch_indices]

batch_size = 10

for x,y in data_iter(batch_size,features,labels):
    print(x,'\n',y)
    break

'''定义初始化模型参数'''
w = torch.normal(0,0.01,size=(2,1),requires_grad=True)
b = torch.zeros(1,requires_grad=True)

'''定义模型'''
def linreg(x, w, b):  #@save
    '''线性回归模型'''
    return torch.matmul(x, w) + b


'''定义损失函数'''
def squared_loss(y_hat,y):
    '''均方损失'''
    return (y_hat - y.reshape(y_hat.shape))**2/2

'''定义优化算法'''
def sgd(params,lr,batch_size):
    '''小批量随机梯度下降'''
    with torch.no_grad():
        for params in params:
            params -= lr * params.grad /batch_size
            params.grad.zero_()    #手动将梯度设为0

'''训练过程'''

lr = 0.03               #学习率
num_epochs = 3          #把数据扫三遍
net = linreg
loss = squared_loss

for epoch in range(num_epochs): #第一层for每一次把数据扫一遍
    for x,y in data_iter(batch_size,features,labels):
        l = loss(net(x,w,b),y)      # x和y是小批量损失
        #因为l形状是（batch_size，1），而不是一个标量
        # 计算l关于[w,b]的梯度
        l.sum().backward()
        sgd([w,b],lr,batch_size)         # 使用参数的梯度更新参数
    with torch.no_grad():
        train_l = loss(net(features,w,b),labels)
        print(f'epoch {epoch + 1}, loss {float(train_l.mean()):f}')

