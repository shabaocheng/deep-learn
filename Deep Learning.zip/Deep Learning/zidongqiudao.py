import torch

x  = torch.arange(4.0)

#计算y关于x的梯度之前，需要一个地方来存我们的梯度
x.requires_grad_(True) #等价于x = torch.arange(4.0,requires_grad=True)
print(x.grad)
#计算y
y = 2*torch.dot(x,x)  #计算内积
print(y)

#通过调用反向传播函数来自动计算y关于每个x每个分量的梯度
print(y.backward())    #求导
print(x.grad)

#现在我们计算x的另一个函数
#在默认的情况下，Pytorch会累积梯度，我们需要清除之前的值
x.grad.zero_()    #_表示重写函数的内容
y = x.sum()       #求x的sum梯度为全1
y.backward()
print(x.grad)
print('\n')

#将某些计算移动到记录的计算图之外
x.grad.zero_()  #清零梯度
y = x * x
u = y.detach()       #detach()把y当作一个常数，而不是关于x的函数。
z = u * x
z.sum().backward()
print(x.grad == u)      #求导结果为u


#即使构建函数的计算图需要通过Python控制流（例如，条件、循环或任意函数调用），我们仍然可以计算得到的变量的梯度。
def f(a):
    b = a * 2
    while b.norm() < 1000:      #norm()为l2范数
        b = b * 2
    if b.sum() > 0:
        c = b
    else:
        c = 100 * b
    return c
a = torch.randn(size=(), requires_grad=True)
d = f(a)
d.backward()
print(a.grad == d / a)

